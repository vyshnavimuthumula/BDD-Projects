package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class DIspatchedProductsPageFactory {
	WebDriver driver;
	@FindBy(id="all")
	@CacheLookup
	WebElement updateButton;
	public WebDriver getDriver() {
		return driver;
	}
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	
	public WebElement getUpdateButton() {
		return updateButton;
	}
	public void setUpdateButton() {
		this.updateButton.click();
	}
}
