package UpdatingStatus;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBean.UpdatingStatusPageFactory;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UpdatingStatusStepDefs {
	WebDriver driver;
	UpdatingStatusPageFactory updatingStatusPageFactory;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\vymuthum\\Documents\\BDD Workspace\\chromedriver_win32\\chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	
	@Given("^User is on updatingstatus page$")
	public void user_is_on_updatingstatus_page() throws Throwable {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		updatingStatusPageFactory = new UpdatingStatusPageFactory(driver);

		driver.get("http://localhost:4200/");
	}

	@Then("^check the heading of the page$")
	public void check_the_heading_of_the_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}

	@When("^user clicks all button\\.$")
	public void user_clicks_all_button() throws Throwable {
		updatingStatusPageFactory.setAllButton();
	}

	@Then("^displays 'Product details whose status equals to PLD or DISP'\\.$")
	public void displays_Product_details_whose_status_equals_to_PLD_or_DISP() throws Throwable {
		driver.get("file:///C:/Users/vymuthum/Documents/BDD%20Workspace/deliveryStatus.html");
	}

	@When("^user clicks placed button\\.$")
	public void user_clicks_placed_button() throws Throwable {
		updatingStatusPageFactory.getPlacedButton();
	}

	@Then("^displays 'Product details whose status equals to PLD'\\.$")
	public void displays_Product_details_whose_status_equals_to_PLD() throws Throwable {
		driver.get("http://localhost:4200/placedProducts/");
	}
	
	@When("^user clicks dispatched button\\.$")
	public void user_clicks_disptached_button() throws Throwable {
		updatingStatusPageFactory.getDispatchedButton();
	}
	@Then("^displays 'Product details whose status equals to DISP'\\.$")
	public void displays_Product_details_whose_status_equals_to_DISP() throws Throwable {
		driver.get("http://localhost:4200/dispatchedProducts/");
	}


}
