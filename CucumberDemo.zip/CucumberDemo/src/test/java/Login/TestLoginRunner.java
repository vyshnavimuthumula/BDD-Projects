package Login;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="C:\\Users\\vymuthum\\Documents\\BDD Workspace\\CucumberDemo\\src\\main\\resources\\Login",glue="Logoin",plugin="pretty")
public class TestLoginRunner {

}
