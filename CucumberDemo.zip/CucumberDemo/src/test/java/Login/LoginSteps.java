package Login;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.cg.bdd.bean.User;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {
	@Given("^User is on Home page$")
	public void user_is_on_Home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	}

	@Given("^Login link is available$")
	public void login_link_is_available() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}
    User user1=new User();
	@When("^user enters user name and password$")
	public void user_enters_user_name_and_password() throws Throwable {
	
	    user1.setUsername("vyshu");
	    user1.setPassword("vyshu123");
	}

	@When("^if entered credentials are correct$")
	public void if_entered_credentials_are_correct() throws Throwable {
	    assertEquals(user1.getUsername(),"vyshu");
	    assertEquals(user1.getPassword(),"vyshu123");
	}

	@Then("^Display message as 'successful Login'$")
	public void display_message_as_successful_Login() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}

	@When("^if entered credentials are incorrect$")
	public void if_entered_credentials_are_incorrect() throws Throwable {
		 assertNotEquals(user1.getUsername(),"vy6shu");
		 assertNotEquals(user1.getPassword(),"vys76hu123");
	}

	@Then("^Display message as 'unsuccessful Login'$")
	public void display_message_as_unsuccessful_Login() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}
}
