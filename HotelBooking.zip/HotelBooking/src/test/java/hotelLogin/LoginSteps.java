package hotelLogin;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.bdd.bean.User;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {
	private WebDriver driver;
	private User user;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\vymuthum\\Documents\\BDD Workspace\\chromedriver_win32\\chromedriver.exe");
		
		driver= new ChromeDriver();
	}
	@Given("^User is on 'login' Page$")
	public void user_is_on_login_Page() throws Throwable {
		driver.get("file:///C:/Users/vymuthum/Documents/BDD Workspace/BDDCaseStudyFinal//login.html");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        user = new User(driver);
		//throw new PendingException();
	}

	@When("^user enters invalid UserName$")
	public void user_enters_invalid_UserName() throws Throwable {
		 user.setPfuname("");
		 user.setPflogin();
         driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	   // throw new PendingException();
	}

	@Then("^display 'Please Enter UserName'$")
	public void display_Please_Enter_UserName() throws Throwable {
		String expectedMessage="* Please enter userName.";
		String actualMessage=user.getPfuname().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();	
	}

	@When("^user enters invalid password$")
	public void user_enters_invalid_password() throws Throwable {
		user.setPfuname("Yogini");
		user.setPfpwd("");
		user.setPflogin();
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
       // driver.close();	
	}

	@Then("^display 'Please Enter Password'$")
	public void display_Please_Enter_Password() throws Throwable {
		String expectedMessage="* Please enter password.";
		String actualMessage=user.getPfuname().getText();
		
		if(expectedMessage.equals(actualMessage))
			driver.switchTo().alert().accept();
		else
			System.out.println("Correct Password...");
		
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.close();	
	}
	@When("^user enters invalid details$")
	public void user_enters_invalid_details() throws Throwable {
		user.setPfuname("Yogini");
        user.setPfpwd("");
         driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
         user.setPflogin();
         driver.close();	
         
	}

	@Then("^display 'Invalid Login Please try again'$")
	public void display_Invalid_Login_Please_try_again() throws Throwable {
		String expectedMessage="* Please enter userName.";
		String actualMessage=user.getPfuname().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();	
	}



	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		user.setPfuname("Yogini");
        user.setPfpwd("Yogini");
         driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
         user.setPflogin();
	}

	@Then("^display 'HotelBooking' Page$")
	public void display_HotelBooking_Page() throws Throwable {
		 driver.navigate().to("file:///C:/Users/vymuthum/Documents/BDD Workspace/BDDCaseStudyFinal/hotelbooking.html");
        // driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        // driver.close();	
	}
	
	
}
