package Login;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.bdd.bean.User;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

 

public class Test_Steps {
    WebDriver driver;
    private User objhlpg;
    
    @Given("^User is on 'login' Page$")
    public void user_is_on_login_Page() throws Throwable {
        //driver = new FirefoxDriver();
        
System.setProperty("webdriver.chrome.driver", "C:/Users/vyateesh/Desktop/bdd/chromedriver.exe");
         driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        objhlpg = new User(driver);
        driver.get("file:///C:/Users/vyateesh/AppData/Local/Temp/7zO08E3380B/login.html");
    }
    @When("^user enters invalid UserName$")
    public void user_enters_invalid_UserName() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
         objhlpg.setPfuname("gshhgf");
         driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        throw new PendingException();
    }

 

    @Then("^display 'Please Enter UserName'$")
    public void display_Please_Enter_UserName() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        objhlpg.setPfuname("");
         driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        throw new PendingException();
    }

 

    @When("^user enters invalid password$")
    public void user_enters_invalid_password() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        objhlpg.setPfpwd("djfg");
         driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        throw new PendingException();
    }

 

    @Then("^display 'Please Enter Password'$")
    public void display_Please_Enter_Password() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

 

    @When("^user enters invalid details$")
    public void user_enters_invalid_details() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        objhlpg.setPfuname("capgemini");
        objhlpg.setPfpwd("capg1234@1");
         driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        throw new PendingException();
    }

 

    @Then("^display 'Invalid Login Please try again'$")
    public void display_Invalid_Login_Please_try_again() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        throw new PendingException();
    }

 

    @When("^user enters valid details$")
    public void user_enters_valid_details() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        objhlpg.setPfuname("capgemini");
        objhlpg.setPfpwd("capg1234");
         driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
         objhlpg.setPflogin();
        throw new PendingException();
    }

 

    @Then("^display 'HotelBooking' Page$")
    public void display_HotelBooking_Page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
         driver.navigate().to("file:///C://Users//vyateesh//Desktop//hotelBooking/hotelbooking.html");
         driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
         //driver.close();
//        throw new PendingException();
    }   
}