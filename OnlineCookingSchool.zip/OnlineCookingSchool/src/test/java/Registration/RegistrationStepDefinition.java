package Registration;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.RegistrationPageFactory;


public class RegistrationStepDefinition {
	
	private WebDriver driver;
	
	//Bean factory
	private RegistrationPageFactory registrationPageFactory;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\vymuthum\\Documents\\BDD Workspace\\chromedriver_win32\\chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	@Given("^User is on 'registration form' page$")
	public void user_is_on_registration_form_page() throws Throwable {
		driver.get("C:\\Users\\vymuthum\\Documents\\BDD Workspace\\OnlineCooking\\Recipe_class_registration.html");
		registrationPageFactory= new RegistrationPageFactory(driver);
	}
//
	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		//driver.get("C:\\\\Users\\\\vymuthum\\\\Documents\\\\BDD Workspace\\\\OnlineCooking\\\\Recipe_class_registration.html");

		String actualTitle = driver.findElement(By.xpath("//*/title")).getText();
	
		System.out.println("The page title is :" + actualTitle);
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	}

	@Then("^check the text on the web page$")
	public void check_the_text_on_the_web_page() throws Throwable {
		String expectedMessage="Recipe class brochre is sent to your registered mail id";
		String actualMessage=driver.switchTo().alert().getText();
		if(expectedMessage.equals(actualMessage))
			driver.switchTo().alert().accept();
		
		
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.get("C:\\Users\\vymuthum\\Documents\\BDD Workspace\\OnlineCooking.Recipe_class_registration.html");
	}

	

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
		registrationPageFactory.setFirstName("");
		registrationPageFactory.setEnquireNow();
	}

	@Then("^displays 'First Name must be filled'$")
	public void displays_First_Name_must_be_filled() throws Throwable {
		String expectedMessage="First Name must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		if(expectedMessage.equals(actualMessage))
			driver.switchTo().alert().accept();
		else
			System.out.println("firstname filled");
		driver.close();
	}

	

	@When("^user enters invalid last name$")
	public void user_enters_invalid_last_name() throws Throwable {
		registrationPageFactory.setFirstName("vyshnavi");
		registrationPageFactory.setLastName("");
		registrationPageFactory.setEnquireNow();
		
	}

	@Then("^displays 'Last Name must be filled out'$")
	public void displays_Last_Name_must_be_filled_out() throws Throwable {
		String expectedMessage="Last Name must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		if(expectedMessage.equals(actualMessage))
			driver.switchTo().alert().accept();
		else
			System.out.println("Lastname filled");
		driver.close();
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		registrationPageFactory.setFirstName("vyshnavi");
		registrationPageFactory.setLastName("muthu");
		registrationPageFactory.setEmail("");
		//registrationPageFactory.setEnquireNow();
	}

	@When("^user enters non numeric value and clicks the button$")
	public void user_enters_non_numeric_value_and_clicks_the_button() throws Throwable {
		registrationPageFactory.setFirstName("vyshnavi");
		registrationPageFactory.setLastName("muthu");
		registrationPageFactory.setEmail("abc@gmail.com");
		registrationPageFactory.setMobileNo("");
		registrationPageFactory.setEnquireNow();
		
	}

	@Then("^display alert msg like 'Enter numeric value'$")
	public void display_alert_msg_like_Enter_numeric_value() throws Throwable {
		String expectedMessage="Enter numeric value.";
		String actualMessage=driver.switchTo().alert().getText();
		if(expectedMessage.equals(actualMessage))
			driver.switchTo().alert().accept();
		else
			System.out.println("mobile filled");
		driver.close();
	}

	

	@When("^user enters incorrect mobileNo format and clicks the button$")
	public void user_enters_incorrect_mobileNo_format_and_clicks_the_button(DataTable arg1) throws Throwable {
		registrationPageFactory.setFirstName("vyshnavi");
		registrationPageFactory.setLastName("muthu");
		registrationPageFactory.setEmail("abc@gmail.com");
		registrationPageFactory.setMobileNo("098345");
		registrationPageFactory.setEnquireNow();
	}

	@Then("^display alert message like 'Enter (\\d+) digit Mobile number'$")
	public void display_alert_message_like_Enter_digit_Mobile_number(int arg1) throws Throwable {
		String expectedMessage="Enter 10 digit Mobile number";
		String actualMessage=driver.switchTo().alert().getText();
		if(expectedMessage.equals(actualMessage))
			driver.switchTo().alert().accept();
		else
			System.out.println("mobile filled");
		driver.close();
	}

	@When("^user enters invalid catagory$")
	public void user_enters_invalid_catagory() throws Throwable {
		registrationPageFactory.setFirstName("vyshnavi");
		registrationPageFactory.setLastName("muthu");
		registrationPageFactory.setEmail("abc@gmail.com");
		registrationPageFactory.setMobileNo("098345");
		registrationPageFactory.setCatagory("veg");
		registrationPageFactory.setEnquireNow();
	}

	@Then("^display 'select dropdown as Non-Veg'$")
	public void display_select_dropdown_as_Non_Veg() throws Throwable {
//		String expectedMessage="Enter 10 digit Mobile number";
//		String actualMessage=driver.switchTo().alert().getText();
//		if(expectedMessage.equals(actualMessage))
//			driver.switchTo().alert().accept();
//		else
//			System.out.println("mobile filled");
//		driver.close();
	}

	@When("^user enters invalid city$")
	public void user_enters_invalid_city() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	}

	@Then("^display 'select preference as Mumbai'$")
	public void display_select_preference_as_Mumbai() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	}

	@When("^user enters invalid mode$")
	public void user_enters_invalid_mode() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	}
//in html there is no alert msg so i didnot implement the this method
	@Then("^display 'select Mode of the learing as In house training'$")
	public void display_select_Mode_of_the_learing_as_In_house_training() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	}

	@When("^user enters invalid course duration$")
	public void user_enters_invalid_course_duration() throws Throwable {
		registrationPageFactory.setFirstName("vyshnavi");
		registrationPageFactory.setLastName("muthu");
		registrationPageFactory.setEmail("abc@gmail.com");
		registrationPageFactory.setMobileNo("098345");
		registrationPageFactory.setCatagory("veg");
		registrationPageFactory.setEnquireNow();
	}

	@Then("^display 'select course duration as (\\d+) months'$")
	public void display_select_course_duration_as_months(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	}

	@When("^user does not enter anything and clicks on enquiry button$")
	public void user_does_not_enter_anything_and_clicks_on_enquiry_button() throws Throwable {
		registrationPageFactory.setFirstName("vyshnavi");
		registrationPageFactory.setCatagory("veg");
		registrationPageFactory.setEnqDetails("vegfdsg");
		registrationPageFactory.setEnquireNow();
	}

	@Then("^display alert as 'Enquiry details must be filled out'$")
	public void display_alert_as_Enquiry_details_must_be_filled_out() throws Throwable {
		String expectedMessage="Enquiry details must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		if(expectedMessage.equals(actualMessage))
			driver.switchTo().alert().accept();
		driver.close();
	}
//after entering all details correctly click on enquiry button
	@When("^user enters valid details and clicks on enquiry button$")
	public void user_enters_valid_details_and_clicks_on_enquiry_button() throws Throwable {
		registrationPageFactory.setFirstName("vyshnavi");
		registrationPageFactory.setLastName("muthu");
		registrationPageFactory.setEmail("abc@gmail.com");
		registrationPageFactory.setMobileNo("098345");
		registrationPageFactory.setCatagory("veg");
		registrationPageFactory.setEnqDetails("vegfdsg");
		registrationPageFactory.setEnquireNow();
		
	}

	@Then("^display 'Our loaction representative will contact you soon'$")
	public void display_Our_loaction_representative_will_contact_you_soon() throws Throwable {
		String expectedMessage="Thank you for submitting the online recipe class Enquiry";
		String actualMessage=driver.switchTo().alert().getText();
		if(expectedMessage.equals(actualMessage))
			driver.switchTo().alert().accept();
		String expectedMessage1="Our location representative will contact you soon.";
		String actualMessage1=driver.switchTo().alert().getText();
		if(expectedMessage1.equals(actualMessage1))
			System.out.println("Successfully registered");
		//driver.close();
	}


	
}
