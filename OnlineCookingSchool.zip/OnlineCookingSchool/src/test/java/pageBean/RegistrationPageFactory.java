package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
public class RegistrationPageFactory {
	WebDriver driver;
	// step 1:identify form elements
	@FindBy(name="fname")
	@CacheLookup
	WebElement firstName;
	@FindBy(xpath="//*[@id='lname']")
	@CacheLookup
	WebElement lastName;
	@FindBy(how=How.NAME, using="email")
	@CacheLookup
	WebElement email;
	@FindBy(name="mobile")
	@CacheLookup
	WebElement mobileNo;
	
	@FindBy(how=How.NAME, using="D6")
	@CacheLookup
	WebElement catagory;
	@FindBy(how=How.NAME, using="D5")
	@CacheLookup
	WebElement city;
	@FindBy(how=How.NAME, using="D4")
	@CacheLookup
	WebElement mode;
	@FindBy(how=How.NAME, using="D4")
	@CacheLookup
	WebElement courseDuration;
	@FindBy(id="enqdetails")
	@CacheLookup
	WebElement enqDetails;
	//using how class
	@FindBy(how=How.ID, using="Submit1")
	@CacheLookup
	WebElement enquireNow;
	
	public RegistrationPageFactory(WebDriver driver2) {
		// TODO Auto-generated constructor stub
	}
	public WebDriver getDriver() {
		return driver;
	}
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	
	public WebElement getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	
	public WebElement getLastName() {
		return lastName;
	}
	
	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}
	
	public WebElement getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email.sendKeys(email);
	}
	
	public WebElement getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}
	
	public WebElement getCatagory() {
		return catagory;
	}
	public void setCatagory(String catagory) {
		this.catagory.sendKeys(catagory);
	}
	public WebElement getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city.sendKeys(city);
	}
	
	public WebElement getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode.sendKeys(mode);
	}
	
	public WebElement getCourseDuration() {
		return courseDuration;
	}
	public void setCourseDuration(String courseDuration) {
		this.courseDuration.sendKeys(courseDuration);
	}
	public WebElement getEnqDetails() {
		return enqDetails;
	}
	public void setEnqDetails(String enqDetails) {
		this.enqDetails.sendKeys(enqDetails);
	}
	
	public WebElement getEnquireNow() {
		return enquireNow;
	}
	public void setEnquireNow() {
		this.enquireNow.sendKeys();
	}
	
}
